<?php
$fnome=$_POST['nome'];
  $fcognome=$_POST['cognome'];
  $data=$_POST['datadinascita'];
  $femail=$_POST['email'];
  $fcellulare=$_POST['cellulare'];
  $fcodicefiscale  =$_POST['codicefiscale'];
  $abt =$_POST['esper'];
  $esp =$_POST['esperienza'];
  $edu =$_POST['educazione'];
  $lin =$_POST['Lingue'];
  $level  =$_POST['select'];
  $digitali=$_POST['computer'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <title>Cv format</title>
  </head>
  <body bgcolor="#D5D8DC">
<table width="700px" height="800px" align="center">
<tr>
  <td width="200px" bgcolor="	 #99cc00" style="color:white; padding:20px">
  <img src="cattura.jpg" style="border-radius:50%; width:200px; margin-left:10px;" alt="">
  <h3>Dati Profilo</h3><hr>
  <br>
  <label for="Nome">Nome</label>
  <p><?php echo $fnome ?> </p>
  <label for="Nome">cognome</label>
  <p><?php echo $fcognome ?></p>
  <label for="Nome">data di nascita</label>
  <p><?php echo $data ?></p>
  <label for="Nome">email</label>
  <p><?php echo $femail ?></p>
  <label for="Nome">cellulare</label>
  <p><?php echo $fcellulare ?></p>
  <label for="codicefiscale">codicefiscale</label>
  <p><?php echo $fcodicefiscale ?></p>

  <h2>Comunicazione</h2><hr>
  <p> <?php echo $lin ?></p>
  <p><?php echo $level ?></p>

    <h2>Competenza digitali</h2><hr>
    <p> <?php echo $digitali ?></p>

  </td>
  <td width="500px" bgcolor="	 #ff6600" style="padding:15px;">
     <h1>About</h2><hr>
     <p><?php echo $abt ?></p>
         <h3>Esperienza</h3><hr>
         <p><?php echo $esp ?></p>
         <h3>Educazione</h3><hr>
         <p><?php echo $edu ?></p>


  </td>

</tr>


</table>


     </table>

  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  </body>
</html>

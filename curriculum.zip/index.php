<html>
<head>
	<title>Resume </title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
</head>
<body>
	<div class="header">
		<h1>crea il tuo curriculum</h1>
	</div>
<style media="screen">
body{
	background : #0071BC;
  background : rgba(0, 113, 188, 1);
  border-style : Solid;
  border-color : #000000;
  border-color : rgba(0, 0, 0, 1);
  border-width : 1px;
}
.header{

	background : #0071BC;
  background : rgba(0, 113, 188, 1);
  border-style : Solid;
  border-color : #000000;
  border-color : rgba(0, 0, 0, 1);
  border-width : 1px;
}
.nominativo{
	font-size:55px;
	font-family:agency FB;
	font-weight:700;
	border-bottom-style:ridge;
}
h1{
  font-family : Gigi;
  font-size : 73px;
  color : #000000;
  color : rgb(0, 0, 0);
	text-align: center;
}
#form{

	background-color:#0071BC;
	min-height:400px;
	margin-left:220px;
}
.btn-primary{
 border-radius:0px;
 padding:10px;
 width:50%;
 margin-left: 140px;

}

</style>

<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3" id="form">
			<center><b class="Nominativo">Anagrafici</b></center>
			<form action="reg.php" method="POST">
				<div class="form-group">
					<label for="Nome">Nome</label>
					<input type="text" class="form-control" name="nome" value="">
				</div>
				<div class="form-group">
					<label for="cognome">Cognome</label>
					<input type="text" class="form-control" name="cognome" value="">
				</div>
				<div class="form-group">
					<label for="cellulare">Cellulare</label>
					<input type="text" class="form-control" name="cellulare" value="">
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="text" class="form-control" name="email" value="">
				</div>
				<div class="form-group">
					<label for="date">Data di Nascita</label>
					<input type="date" class="form-control" name="datadinascita" value="">
				</div>
				<div class="form-group">
					<label for="date">Codice fiscale</label>
					<input type="text" class="form-control" name="codicefiscale" value="">
				</div>
				<center><b class="Nominativo">About</b></center>

					<div class="form-group">
					<label for="Nome">About</label>
					<textarea class="form-control" name="esper" rows="6" placeholder="Scrivi tua Esperienza"></textarea>
			</div>

				<center><b class="Nominativo">Esperienza</b></center>

					<div class="form-group">
						<label for="Nome">Esperienza</label>
						<textarea class="form-control" name="esperienza" rows="6" placeholder="Scrivi tua Esperienza"></textarea>
			</div>
					<div class="form-group">
						<center><b class="Nominativo">Educazione</b></center>
						<label for="Nome">Educazione</label>
						<textarea class="form-control" name="educazione" rows="6" placeholder="Scrivi tua Educazione"></textarea>
            </div>

					<div class="form-group">
						<label for="lang">Lingua</label>
						<input type="text" class="form-control" name="Lingue">
					</div>
					<div class="form-group">
						<label for="date">lingua madre</label>
					 <select name="select" class="form-control text">
					 <option>A1</option>
						<option >A2</option>
						<option  >B1</option>
						 <option >B2</option>
				 </select>
					</div>

      <center><b class="Nominativo">Compe digitali</b></center>

						<div class="form-group">
							<label for="date">Conoscenza informatica</label>
						 <select name="computer" class="form-control text">
						 <option >Informatica</option>
							<option >Excel</option>
							<option  >Word</option>
							 <option>Internet</option>
					 </select>
<br>
				<div class="form-group">

					<input type="submit" value="Submit" class="btn btn-primary"name="sub">

				</div>
			</form>
		</div>
	</div>
</div>


		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
</body>
</html>
